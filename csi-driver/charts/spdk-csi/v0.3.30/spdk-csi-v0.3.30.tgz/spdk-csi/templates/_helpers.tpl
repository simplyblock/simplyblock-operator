{{/* vim: set filetype=mustache: */}}

{{/* labels for helm resources */}}
{{- define "spdk.labels" -}}
labels:
  heritage: "{{ .Release.Service }}"
  release: "{{ .Release.Name }}"
  revision: "{{ .Release.Revision }}"
  chart: "{{ .Chart.Name }}"
  chartVersion: "{{ .Chart.Version }}"
{{- end -}}

{{- define "simplyblock.controlPlaneAddr" -}}
{{- if .Values.csiConfig.simplybk.ip -}}
{{ .Values.csiConfig.simplybk.ip }}
{{- else if .Values.operator.enabled -}}
http://simplyblock-webappapi.{{ .Release.Namespace }}.svc.cluster.local:5000
{{- end -}}
{{- end -}}

{{- define "simplyblock.commonContainer" }}
env:
  - name: SIMPLYBLOCK_LOG_LEVEL
    valueFrom:
      configMapKeyRef:
        name: simplyblock-config
        key: LOG_LEVEL

volumeMounts:
  - name: fdb-cluster-file
    mountPath: /etc/foundationdb/fdb.cluster
    subPath: fdb.cluster
{{- if .Values.tls.enabled }}
  - name: tls
    mountPath: /etc/simplyblock/tls
    readOnly: true
{{- end }}

resources:
  requests:
    cpu: "50m"
    memory: "100Mi"
  limits:
    cpu: "300m"
    memory: "1Gi"
{{- end }}

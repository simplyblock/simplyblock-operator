{{/*
Whether this profile runs a CSI driver.

The profiles are listed rather than a negation of the ones that do not, so a
profile added later renders no driver until somebody decides it should. The
negation would do the opposite and give every future profile a CSI deployment
by default, which is the wrong way round: a driver registers a provisioner and
takes over the node plugin's socket on every worker, and a profile that wanted
neither would get both by saying nothing.

standalone and managed are here because both run workloads that mount
simplyblock volumes. What differs between them is where the control plane is,
and the driver reaches it through the credentials Secret either way
(design-simplyblockdriver.md §4.3). empty is not: its administrator writes the
SimplyblockDriver, and a chart-rendered one beside it would be a second CSI
deployment.
*/}}
{{- define "simplyblock.rendersCSIDriver" -}}
{{- if has .Values.deployment.profile (list "standalone" "managed") -}}
true
{{- end -}}
{{- end -}}

{{- define "simplyblock.controlPlaneAddr" -}}
{{- if .Values.csiConfig.simplybk.ip -}}
{{ .Values.csiConfig.simplybk.ip }}
{{- else -}}
http://simplyblock-webappapi.{{ .Release.Namespace }}.svc.cluster.local:5000
{{- end -}}
{{- end -}}

{{/*
Volume named "tls" holding only ca.crt, for client-only consumers without mTLS.
- openshift: cabundle ConfigMap (renamed key).
- cert-manager: project ca.crt out of simplyblock-ca-bundle-tls, a Certificate
  issued by the chart's ClusterIssuer into the release namespace. The root CA
  secret lives in the cert-manager namespace and cannot be mounted directly.
Caller pipes through `nindent N`.
*/}}
{{- define "simplyblock.caVolume" -}}
{{- if .Values.tls.enabled -}}
{{- if eq .Values.tls.provider "openshift" }}
- name: tls
  configMap:
    name: simplyblock-certificate-authority
    items:
    - key: service-ca.crt
      path: ca.crt
{{- else if eq .Values.tls.provider "cert-manager" }}
- name: tls
  secret:
    # simplyblock-ca-bundle-tls is issued in the release namespace by the chart's
    # ClusterIssuer, so pods can mount it. The CA secret itself lives in the
    # cert-manager namespace and is not directly mountable from here.
    secretName: simplyblock-ca-bundle-tls
    items:
    - key: ca.crt
      path: ca.crt
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Volume named "tls" for client pods, with optional mTLS.
Args: dict "ctx" $root "clientSecret" <client-cert-secret-name>
- mutual_enabled=false: delegate to simplyblock.caVolume (CA-only mount).
- mutual_enabled=true: project the client cert Secret alongside the
  per-provider CA bundle.
Caller pipes through `nindent N`.
*/}}
{{- define "simplyblock.clientTlsVolume" -}}
{{- $ctx := .ctx -}}
{{- $clientSecret := .clientSecret -}}
{{- if $ctx.Values.tls.enabled -}}
{{- if not $ctx.Values.tls.mutual_enabled -}}
{{- include "simplyblock.caVolume" $ctx }}
{{- else if eq $ctx.Values.tls.provider "openshift" }}
- name: tls
  projected:
    sources:
    - secret:
        name: {{ $clientSecret }}
    - configMap:
        name: simplyblock-certificate-authority
        items:
        - key: service-ca.crt
          path: ca.crt
{{- else if eq $ctx.Values.tls.provider "cert-manager" }}
- name: tls
  secret:
    # cert-manager populates the client cert secret with tls.crt, tls.key, and
    # ca.crt, so a projected volume is not needed.
    secretName: {{ $clientSecret }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Shared TLS volumeMount entry for the "tls" volume, gated on tls.enabled.
Caller pipes through `nindent N` to land it inside a `volumeMounts:` list.
*/}}
{{- define "simplyblock.tlsVolumeMount" -}}
{{- if .Values.tls.enabled }}
- name: tls
  mountPath: /etc/simplyblock/tls
  readOnly: true
{{- end }}
{{- end -}}

{{/*
TLS-related env vars for sbcli containers. Caller pipes through `nindent N`
to land them at the right column inside an `env:` list.
*/}}
{{- define "simplyblock.tlsEnv" -}}
{{- if .Values.tls.enabled }}
- name: SB_TLS_SERVE
  value: "1"
- name: SB_TLS_PROVIDER
  value: {{ .Values.tls.provider | quote }}
{{- end }}
{{- if .Values.tls.mutual_enabled }}
- name: SB_TLS_CLIENT_AUTH
  value: "required"
- name: SB_TLS_CONNECT
  value: "authenticated"
- name: FDB_TLS_CERTIFICATE_FILE
  value: "/etc/simplyblock/tls/tls.crt"
- name: FDB_TLS_KEY_FILE
  value: "/etc/simplyblock/tls/tls.key"
- name: FDB_TLS_CA_FILE
  value: "/etc/simplyblock/tls/ca.crt"
{{- else if .Values.tls.enabled }}
- name: SB_TLS_CONNECT
  value: "anonymous"
{{- end }}
{{- end -}}